import { ServicoDados as JSK } from "../service/ServicoDados.js";

let clientesCache = [];
let carregandoEmBackground = false;

export async function getCountCustomers() {
  const query = `
    SELECT COUNT(*) AS QTD
    FROM VGFCRM_SKMS
  `
  const results = await JSK.consultar(query, null);
  
  if (!results || results.status == 0) {
    console.error("Erro ao buscar total de clientes", error);
    throw new Error("Erro ao buscar total de clientes.");
  }

  return parseInt(results[0].QTD, 10);
}

export async function getCustomers() {
  // Paginação padrão para Oracle 11 usando ROWNUM
  // Dica: Ajuste o "ORDER BY CODPARC" para a coluna que faz sentido no seu CRM
  const query = `
    SELECT * FROM (
      SELECT a.*, ROWNUM rnum FROM (
        SELECT *
        FROM VGFCRM_SKMS
        ORDER BY CODPARC
      ) a
      WHERE ROWNUM <= 1000
    )
    WHERE rnum > 0
  `;
  
  const results = await JSK.consultarDB(query, null);

  if (!results || results.status == 0) {
    throw new Error("Erro ao carregar o lote inicial.");
  }

  return results.resultado;
}
